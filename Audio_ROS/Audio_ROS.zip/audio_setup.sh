sudo apt-get install libasound-dev ffmpeg portaudio19-dev libportaudio2 libportaudiocpp0

pip3 install --user pyaudio speechrecognition librosa sounddevice python_speech_features scipy

